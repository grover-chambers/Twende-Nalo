# Twende Nalo

Delivery App connecting shoppers, shop owners, and riders.